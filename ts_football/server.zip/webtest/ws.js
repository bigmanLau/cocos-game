
var ws = require("nodejs-websocket");
var group = []
/**
 * @param role m 为左边角色 a 为右边角色
 */
var server = ws.createServer(function (conn) {
    console.log("有一个连接")


    conn.on('text', function (str) {
        console.log(str)
        var data = JSON.parse(str)
        switch (data.type) {
            case "create_room":
                //创建房间
                var groupData = {
                    groupName: Math.floor(Math.random() * 300) + new Date().getTime(),
                    groupState: "waiting",
                    leftscore: 0,
                    rightscore: 0,
                    currentRole: "m", //当前角色
                    whoPlaying: "m"//现在谁可以操作
                }
                group.push(groupData);
                //给连接绑定房间名
                conn.groupName = groupData.groupName;
                broadcast(JSON.stringify({ type: "create_room", data: groupData, success: 1 }))
                break;
            case "join_room":
                //加入房间
                if (group.length <= 0) {
                    broadcast(JSON.stringify({ type: "join_room", success: 0, msg: "当前没有房间" }))
                    return;
                }
                for (let i = 0; i < group.length; i++) {
                    if (group[i].groupState === "waiting") {
                        group[i].groupState = "online"
                        group[i].currentRole = "a";
                        conn.groupName = group[i].groupName;
                        broadcast(JSON.stringify({ type: "join_room", data: group[i], success: 1 }))
                        break;
                    }
                }
                break;
            case "leave_room":
                //离开房间
                var groupName = data.data.groupName;
                for (let i = 0; i < group.length; i++) {
                    if (group[i].groupName === groupName) {
                        broadcast(JSON.stringify({ type: "leave_room", data: { groupName: group[i].groupName }, success: 1 }))
                        group.splice(i, 1);
                        conn.close();
                        break;
                    }
                }
                break;
            case "move":
                var whoPlaying = data.data.whoPlaying
                var groupName = conn.groupName;
                for (let i = 0; i < group.length; i++) {
                    if (group[i].groupName === groupName) {
                        group[i].whoPlaying = whoPlaying;
                        break;
                    }
                }
                data.data.groupName=  conn.groupName;
                broadcast(JSON.stringify(data))
                break;
            case "rotate":
                data.data.groupName=  conn.groupName;
                broadcast(JSON.stringify(data))
                break;
            case "score":
                //得分

                //房间名称 
                var groupName = data.data.groupName;
                //当前角色 
                var currentRole = data.data.currentRole

                for (let i = 0; i < group.length; i++) {
                    if (group[i].groupName === groupName) {
                        if (currentRole === "m") {
                            group[i].leftscore++;
                            //改变下次谁来操作
                            group[i].whoPlaying = "a";
                        } else {
                            group[i].rightscore++;
                            //改变下次谁来操作
                            group[i].whoPlaying = "m";
                        }

                        broadcast(JSON.stringify({
                            type: "score",
                            data: {
                                groupName: group[i].groupName,
                                score: group[i].leftscore + ":" + group[i].rightscore,
                                whoPlaying:   group[i].whoPlaying
                            }, success: 1
                        }))

                        break;
                    }
                }
                break;
        }

    })

    conn.on("error", function (err) {
        console.log(2)
        var groupName = conn.groupName;
        for (let i = 0; i < group.length; i++) {
            if (group[i].groupName === groupName) {
                broadcast(JSON.stringify({ type: "leave_room", data: { groupName: group[i].groupName }, success: 1 }))
                group.splice(i, 1);
                conn.close();
                break;
            }
        }
    })

    conn.on("close", function (e) {
        console.log(1)
        var groupName = conn.groupName;
        for (let i = 0; i < group.length; i++) {
            if (group[i].groupName === groupName) {
                broadcast(JSON.stringify({ type: "leave_room", data: { groupName: group[i].groupName }, success: 1 }))
                group.splice(i, 1);
                conn.close();
                break;
            }
        }
    })

}).listen(2333);

function broadcast(str) {
    server.connections.forEach(function (conn) {
        conn.sendText(str)
    })
}

